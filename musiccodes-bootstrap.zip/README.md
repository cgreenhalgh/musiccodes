# Bootstrap installation

Mimimal Vagrant VM to install musiccodes via git version.

## Instructions

Install VirtualBox, Vagrant and Chrome - see [install](install.md).

Download and unzip musiccodes-bootstrap.zip (includes this file).

On Mac OS X double-click/run `musiccodes.command`. 
Note: if you get a security warning (and you still wish to run it) then open `System Preferences`, `Security and Privacy`, and next to the comment `"musiccodes.command" was blocked from opening...` click `Open Anyway`.

On Windows double-click/run `musiccodes.bat`

(Do this each time you reboot your machine or if you aren't sure if it is running)

In Chrome open [http://localhost:3000](http://localhost:3000).

Enjoy!
