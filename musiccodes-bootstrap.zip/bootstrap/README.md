# Bootstrap installation

Mimimal Vagrant VM to install musiccodes via git version.

## Instructions

Install VirtualBox, Vagrant and Chrome - see [install](install.md).

Download and unzip musiccodes-bootstrap.zip (includes this file).

On Mac OS X double-click/run `musiccodes.command`. 

On Windows double-click/run `musiccodes.bat`

(Do this each time you reboot your machine or if you aren't sure if it is running)

In Chrome open [http://localhost:3000](http://localhost:3000).

Enjoy!
